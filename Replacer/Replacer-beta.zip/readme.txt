:: Replacer 2.63 by Undefined
:: www3.telus.net/_/replacer/
:: Email: undefined@telus.net

Description:

 Replacer is an easy to use system file replacer for Windows 2000 and
 XP. It safely replaces protected or in-use system files.

Requirements:

 - Windows XP or 2000
 - Administrator privileges
 - Windows setup CD not in drive
 - Windows Scripting Host 5.6:
    http://tinyurl.com/33yba

Installation:

 Extract Replacer.zip to a folder and run Replacer.cmd.

 To uninstall, delete the folder where Replacer is stored, and remove
 the undo file (%windir%\ReplacerUndo.txt).

Components:

 If you are running Windows 2000 or are experiencing constant
 unexpected errors, download the components package:
  http://www3.telus.net/_/replacer/Components.zip

Explanation:

 Replacer uses a combination of scripts to replace protected system
 files.

 Upon execution, "Clear_WFP_Message.vbs" is extracted. This secondary
 script clears messages regarding Windows File Protection. Access to
 this script is not essential, but recommended. After the replacement,
 this script will run for 15 seconds to ensure that it doesn't miss
 any late messages.

 After the system and replacement files have been specified, a backup
 is created. It is stored in the same folder as the system file, with
 the extension "backup" (such as "notepad.backup"). The replacement
 file is then copied to up to five folders which contain backups of
 the system file.

 As the file is being replaced, a log is written to "ReplacerUndo.txt"
 in the Windows folder. If the replacement prevents the system from
 properly booting, the previous operation can be reversed from the
 recovery console. See the "Recovery" section below.

 Finally, the VBScript is executed to clear any messages, and the
 system file is replaced.

 If Replacer is closed properly (by following the on-screen
 instructions), the temporary folder it uses will be automatically
 deleted.
 
 To view the executed code, open Replacer.cmd in a text editor.

Recovery:

 In some cases, replacing a system file with a corrupt or out-of-date
 file could prevent the system from properly booting.

 Replacer has an "undo" feature to reverse the previous operation from
 the recovery console.

 To undo the last replacement:
  1 : Enter the recovery console:
       - Insert the Windows setup CD
       - Reboot
       - Press "R" at the blue setup screen
       - Win2000 users: Type "C" next
       - Follow the on-screen instructions
  2 : At the "C:\WINDOWS>" prompt, type:
       BATCH ReplacerUndo.txt
  3 : When the operation is complete, type:
       EXIT

 Note the following:
  - Only the most recent operation can be undone
  - Scripts count as one operation, meaning an entire script can be
    undone at once
  - The undo log is cleared next time Replacer is used
  - Restore operations from Replacer cannot be undone from the
    recovery console

Scripting:

 Scripts can be used to replace multiple files at once. A script is
 simply a text file containing a list of files to be replaced. They
 use the general format:
  SysFile,Replacement,Ref#,Optional

 Each script must contain the following line:
  ;; ReplacerScript

 Type the name of the system file to be replaced, followed by a comma,
 then the replacement file.  Do not include the system file path (it
 will be determined automatically). The replacement file should be
 relative to the script, not Replacer:
  notepad.exe,notepad-new.exe

 The word "Restore" can be used to restore a file from a backup copy,
 if it was previously replaced with Replacer:
  notepad.exe,Restore

 Comments can be added with a single semicolon.  Lines containing a
 semicolon will be skipped:
  ; This is a comment

 If the system file and the replacement file have the same filename,
 only one of them needs to be specified:
  notepad.exe

 Files with multiple paths can be identified using a reference
 number. This is placed at the end of the line, after a comma. If the
 file's reference number is zero, the number can be omitted:
  ; Replace notepad.exe in the windows folder
  notepad.exe,notepad.new
  ; Replace notepad.exe in the system32 folder
  notepad.exe,notepad.new,1
  ; Replace the Metallic shellstyle.dll
  shellstyle.dll,shellstyle.new,2

 List of files with reference numbers:
  Comctl32,0   = %windir%\system32\comctl32.dll
  Comctl32,1   = %windir%\WinSxS\x86_Microsoft.Windows.Common-Controls
                 _6595b64144ccf1df_6.0.0.0_x-ww_1382d70a\comctl32.dll
  Comctl32,2   = %windir%\WinSxS\x86_Microsoft.Windows.Common-Controls
                 _6595b64144ccf1df_6.0.10.0_x-ww_f7fb5805\comctl32.dll
  Comctl32,3   = %windir%\WinSxS\x86_Microsoft.Windows.Common-Controls
                 _6595b64144ccf1df_6.0.2600.1331_x-ww_7abf6d02\comctl32.dll
  Comctl32,4   = %windir%\WinSxS\x86_Microsoft.Windows.Common-Controls
                 _6595b64144ccf1df_6.0.2600.1515_x-ww_7bb98b8a\comctl32.dll
  Comctl32,5   = %windir%\WinSxS\x86_Microsoft.Windows.Common-Controls
                 _6595b64144ccf1df_6.0.2600.2180_x-ww_a84f1ff9\comctl32.dll
  Commdlg,0    = %windir%\system\commdlg.dll
  Commdlg,1    = %windir%\system32\commdlg.dll
  Notepad,0    = %windir%\notepad.exe
  Notepad,1    = %windir%\system32\notepad.exe
  Shellstyle,0 = %windir%\system32\shellstyle.dll
  Shellstyle,1 = %windir%\Resources\Themes\Luna\Shell\NormalColor\shellstyle.dll
  Shellstyle,2 = %windir%\Resources\Themes\Luna\Shell\Metallic\shellstyle.dll
  Shellstyle,3 = %windir%\Resources\Themes\Luna\Shell\Homestead\shellstyle.dll

 The word "Optional" can be used to ask the user whether or not to
 replace a file:
  notepad.exe,notepad.new,Optional

 To execute the script, drag and drop it onto the Replacer.cmd
 file. Or, run Replacer from the command line with the script as a
 parameter.

 Sample script:
  ;; ReplacerScript
  ; Replace and restore notepad
  notepad.exe,notepad.new
  notepad.exe,Restore
  ; Optionally replace Commdlg
  commdlg.dll,new.dll,1,Optional

Acknowledgements:

 Thanks to the whole VirtualPlastic group, and:
  - Michel Gallant for portions of the VBS
  - Explicit, schmin, demlak, and spyder for testing Replacer in its
    early stages
  - Simon Sheppard and Frank P. Westlake for portions of the dequote
    function
  - Michael Harris for the "kill flag" concept
  - Ritchie Lawrence for the wildcard checker
  - Phil Robyn for the comma expansion idea
  - Plastic for the DLL list and WFP circumvention idea
  - WinT for his article on Replacer
  - Simon, flyakite, fireball, and Odyssey for suggesting files to add
    to the db
  - Tomcat76, Enkaiyaju, spyder, grindlestone, Adam L., Joona B., Rual
    A.C., dreamz, Bubka, Devil in Disguise, and R. Lau for providing
    feedback
  - Julien, Explicit, iridium, imokruok, qoa, Ace Troubleshooter,
    Anibal R., KingManon, Tau, chevrolet, enfusion, cfm, Peter C.,
    Babis, Daniel, SOD, plastic, Erbol T., and Florian H for helping
    find bugs.

Licence:

 Public domain.

Contact:

 Send problems or feedback to:
  undefined@telus.net
